defmodule ToyRobot.Position do
  defstruct x: 0, y: 0, facing: :north
end
